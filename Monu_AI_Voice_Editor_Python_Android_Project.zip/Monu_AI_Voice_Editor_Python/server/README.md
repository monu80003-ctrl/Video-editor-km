# Voice Conversion API backend contract

The Android app expects a separate HTTPS service. This folder documents the service boundary; it does not ship a voice-conversion model.

For a real implementation, deploy a GPU-backed service that:
- enrolls the user's own voice sample into a protected profile
- extracts speech from the input video
- performs source separation if needed
- runs voice conversion with timing/prosody preservation
- remixes speech with retained background audio
- muxes final audio into MP4 using FFmpeg

Implement endpoints described in the root README. Protect uploads with authentication, rate limits, file-size limits, deletion controls, and HTTPS. Do not expose model credentials in the Android app or a public GitHub repository.
