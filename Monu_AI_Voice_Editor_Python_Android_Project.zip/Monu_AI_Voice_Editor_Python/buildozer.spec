[app]
title = Monu AI Voice Editor
package.name = monuaivoiceeditor
package.domain = com.monu
source.dir = .
source.include_exts = py,kv,png,jpg,json,md
version = 0.1.0
requirements = python3,kivy==2.3.0,plyer,pyjnius,requests
orientation = portrait
fullscreen = 0

android.permissions = RECORD_AUDIO,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,INTERNET
android.api = 33
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
