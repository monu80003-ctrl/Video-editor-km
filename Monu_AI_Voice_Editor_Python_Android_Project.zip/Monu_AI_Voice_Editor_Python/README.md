# Monu AI Voice Editor — Python Android Project

A Python/Kivy Android app scaffold for a personal voice-conversion video editor.

## What is implemented
- Kivy Android-friendly interface
- Select a video from device storage (Plyer file chooser where supported)
- Record a personal voice sample using Android `MediaRecorder` through Pyjnius
- Save/manage a local voice sample
- Choose a video and submit it to a configurable voice-conversion API
- Poll job status and download the converted MP4
- Build APK with GitHub Actions + Buildozer

## Important: voice conversion is not an offline feature in this starter
A real voice-conversion model is required to transform speech in an arbitrary video into your own voice. This project does not pretend that a fake conversion has happened.
Set `MONU_API_BASE` to a server implementing the API contract below. The server must use a voice-conversion model and FFmpeg/audio separation pipeline. You can host it on a GPU cloud service. A Samsung M30 / Android 11 is not suitable for running most high-quality voice-conversion models locally.

## API contract
Base URL: `https://YOUR-SERVER`

1. `POST /v1/voice-samples`
   - multipart fields: `audio` (wav/m4a), `profile_name`
   - response JSON: `{"profile_id":"..."}`
2. `POST /v1/convert`
   - multipart fields: `video` (mp4/mov), `profile_id`
   - response JSON: `{"job_id":"..."}`
3. `GET /v1/jobs/{job_id}`
   - response JSON: `{"status":"queued|processing|completed|failed", "progress":0..100, "download_url":"https://.../result.mp4", "error":"..."}`
4. `GET /v1/profiles`
   - response JSON: `{"profiles":[{"profile_id":"...","name":"..."}]}`

The server should:
- extract speech from the source video
- separate speech from music/noise where possible
- convert speech timbre to the user's enrolled voice while preserving words/timing/prosody as much as the model supports
- mix converted speech with retained background audio
- mux final audio with the original video
- return a downloadable MP4

Only upload voice samples you own or have explicit permission to use. Use voice conversion transparently and do not impersonate someone deceptively.

## Run on Android
This project is designed to be built in GitHub Actions, not directly on the phone. On your phone:
1. Create a GitHub repository.
2. Upload the full contents of this folder (including hidden `.github` folder).
3. Open the **Actions** tab and run **Build Android APK**.
4. Download the APK from the workflow Artifacts.

## Build locally (Linux)
Install Buildozer and Android build dependencies, then:
```bash
buildozer android debug
```

## Configure API
Before building, edit `main.py` and set `API_BASE` to your server URL, or set it through a build-time environment/config approach. Never put secret API keys directly in a public repository. This starter sends no secret key by default. Add authentication on your server and store credentials securely for a private deployment.

## Limitations of this first version
- Basic video selection and voice-sample recording are included.
- Full multitrack timeline, clip trimming UI, waveform editor, and local FFmpeg rendering are not implemented yet.
- Those should be added after the core conversion API is connected and tested.
