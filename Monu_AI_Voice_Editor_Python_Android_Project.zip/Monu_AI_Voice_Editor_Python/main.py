import os
import json
import threading
import urllib.request
import urllib.parse
import urllib.error
import mimetypes
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import StringProperty, NumericProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.utils import platform

try:
    from plyer import filechooser
except Exception:
    filechooser = None

API_BASE = os.environ.get("MONU_API_BASE", "https://YOUR-VOICE-CONVERSION-SERVER")
APP_DIR = Path(os.environ.get("MONU_DATA_DIR", str(Path.home() / "MonuVoiceEditor")))
APP_DIR.mkdir(parents=True, exist_ok=True)
VOICE_SAMPLE = APP_DIR / "my_voice_sample.m4a"
CONFIG_FILE = APP_DIR / "settings.json"


KV = r"""
<RootUI>:
    orientation: "vertical"
    padding: "14dp"
    spacing: "10dp"
    canvas.before:
        Color:
            rgba: (0.035, 0.065, 0.11, 1)
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        size_hint_y: None
        height: "54dp"
        Label:
            text: "[b]MONU AI VOICE EDITOR[/b]"
            markup: True
            font_size: "19sp"
            color: (0.92, 0.96, 1, 1)
            halign: "left"
            valign: "middle"
            text_size: self.size

    Label:
        text: "अपनी आवाज रिकॉर्ड करें • वीडियो चुनें • अपनी आवाज में बदलें"
        size_hint_y: None
        height: "38dp"
        color: (0.70, 0.81, 0.92, 1)
        font_size: "13sp"

    BoxLayout:
        size_hint_y: None
        height: "82dp"
        spacing: "8dp"
        canvas.before:
            Color:
                rgba: (0.08, 0.14, 0.23, 1)
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [14]
        BoxLayout:
            orientation: "vertical"
            padding: "10dp"
            Label:
                text: "[b]VOICE PROFILE[/b]"
                markup: True
                color: (0.85, 0.91, 1, 1)
                halign: "left"
                text_size: self.size
            Label:
                text: root.voice_status
                color: (0.52, 0.85, 0.72, 1)
                halign: "left"
                text_size: self.size
        Button:
            text: "रिकॉर्ड करें"
            size_hint_x: None
            width: "112dp"
            on_release: root.start_recording()

    Button:
        text: "रिकॉर्डिंग रोकें / सेव करें"
        size_hint_y: None
        height: "46dp"
        background_normal: ""
        background_color: (0.14, 0.39, 0.62, 1)
        on_release: root.stop_recording()

    BoxLayout:
        size_hint_y: None
        height: "88dp"
        spacing: "8dp"
        canvas.before:
            Color:
                rgba: (0.08, 0.14, 0.23, 1)
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [14]
        BoxLayout:
            orientation: "vertical"
            padding: "10dp"
            Label:
                text: "[b]SOURCE VIDEO[/b]"
                markup: True
                color: (0.85, 0.91, 1, 1)
                halign: "left"
                text_size: self.size
            Label:
                text: root.video_name
                color: (0.72, 0.81, 0.91, 1)
                halign: "left"
                text_size: self.size
                font_size: "12sp"
        Button:
            text: "वीडियो चुनें"
            size_hint_x: None
            width: "112dp"
            on_release: root.pick_video()

    Button:
        text: "मेरी आवाज में बदलें"
        size_hint_y: None
        height: "54dp"
        background_normal: ""
        background_color: (0.08, 0.55, 0.38, 1)
        bold: True
        on_release: root.convert_video()

    ProgressBar:
        max: 100
        value: root.progress
        size_hint_y: None
        height: "10dp"

    Label:
        text: root.status_text
        color: (0.88, 0.92, 0.98, 1)
        text_size: self.width, None
        size_hint_y: None
        height: self.texture_size[1] + dp(16)
        font_size: "13sp"

    Widget:

    Label:
        text: "नोट: Voice Conversion के लिए निजी AI सर्वर/API कनेक्ट करना जरूरी है।"
        color: (0.58, 0.69, 0.81, 1)
        font_size: "11sp"
        size_hint_y: None
        height: "32dp"
"""


class RootUI(BoxLayout):
    voice_status = StringProperty("अभी आवाज रिकॉर्ड नहीं हुई")
    video_name = StringProperty("कोई वीडियो नहीं चुना")
    status_text = StringProperty("शुरू करने के लिए अपनी आवाज रिकॉर्ड करें।")
    progress = NumericProperty(0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.video_path = None
        self.recorder = None
        self.recording_path = str(VOICE_SAMPLE)
        if VOICE_SAMPLE.exists():
            self.voice_status = "Voice sample सेव है"

    def show_message(self, message):
        Popup(title="Monu AI Voice Editor",
              content=Label(text=message),
              size_hint=(0.88, 0.38)).open()

    def _request_android_permissions(self):
        if platform != "android":
            return True
        try:
            from android.permissions import request_permissions, Permission
            request_permissions([
                Permission.RECORD_AUDIO,
                Permission.READ_EXTERNAL_STORAGE,
                Permission.WRITE_EXTERNAL_STORAGE,
            ])
            return True
        except Exception:
            return False

    def start_recording(self):
        self._request_android_permissions()
        if platform != "android":
            self.status_text = "रिकॉर्डिंग टेस्ट के लिए Android डिवाइस पर चलाएँ।"
            return
        try:
            from jnius import autoclass
            MediaRecorder = autoclass("android.media.MediaRecorder")
            BuildVersion = autoclass("android.os.Build$VERSION")
            self.recorder = MediaRecorder()
            if int(BuildVersion.SDK_INT) >= 31:
                self.recorder.setAudioSource(1)  # MIC
            else:
                self.recorder.setAudioSource(1)
            self.recorder.setOutputFormat(2)  # MPEG_4
            self.recorder.setAudioEncoder(3)  # AAC
            self.recorder.setOutputFile(self.recording_path)
            self.recorder.prepare()
            self.recorder.start()
            self.status_text = "रिकॉर्डिंग चालू है। साफ आवाज में 1–3 मिनट बोलें।"
        except Exception as exc:
            self.status_text = "रिकॉर्डिंग शुरू नहीं हुई: " + str(exc)

    def stop_recording(self):
        if self.recorder is None:
            self.status_text = "पहले रिकॉर्डिंग शुरू करें।"
            return
        try:
            self.recorder.stop()
            self.recorder.release()
            self.recorder = None
            if VOICE_SAMPLE.exists() and VOICE_SAMPLE.stat().st_size > 1000:
                self.voice_status = "Voice sample सेव है"
                self.status_text = "आपकी आवाज रिकॉर्डिंग सेव हो गई।"
            else:
                self.status_text = "रिकॉर्डिंग फाइल नहीं मिली। दोबारा प्रयास करें।"
        except Exception as exc:
            self.status_text = "रिकॉर्डिंग सेव करने में समस्या: " + str(exc)
            self.recorder = None

    def pick_video(self):
        if filechooser is None:
            self.show_message("इस डिवाइस पर फाइल पिकर उपलब्ध नहीं है।")
            return
        try:
            filechooser.open_file(on_selection=self._video_selected,
                                  filters=["*.mp4", "*.mov", "*.m4v", "*.3gp"])
        except Exception as exc:
            self.show_message("वीडियो चुनने में समस्या: " + str(exc))

    def _video_selected(self, selection):
        if not selection:
            return
        self.video_path = selection[0]
        self.video_name = os.path.basename(self.video_path)
        self.status_text = "वीडियो चुना गया। अब 'मेरी आवाज में बदलें' दबाएँ।"

    def convert_video(self):
        if not VOICE_SAMPLE.exists():
            self.show_message("पहले अपनी आवाज रिकॉर्ड करें।")
            return
        if not self.video_path or not os.path.exists(self.video_path):
            self.show_message("पहले वीडियो चुनें।")
            return
        if "YOUR-VOICE-CONVERSION-SERVER" in API_BASE:
            self.show_message(
                "AI सर्वर अभी सेट नहीं है। GitHub पर कोड डालने के बाद अपना निजी "
                "Voice Conversion API URL main.py में API_BASE में सेट करना होगा। "
                "बिना असली AI मॉडल के ऐप आवाज बदलने का दावा नहीं करेगा।"
            )
            return
        self.status_text = "वीडियो सर्वर पर भेजा जा रहा है…"
        self.progress = 5
        threading.Thread(target=self._upload_and_poll, daemon=True).start()

    def _multipart(self, fields, file_field, file_path):
        boundary = "----MonuVoiceEditorBoundary7MA4YWxkTrZu0gW"
        body = bytearray()
        for key, value in fields.items():
            body.extend(("--" + boundary + "\r\n").encode())
            body.extend((f'Content-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n').encode())
        filename = os.path.basename(file_path)
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        body.extend(("--" + boundary + "\r\n").encode())
        body.extend((f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\n').encode())
        body.extend((f"Content-Type: {mime}\r\n\r\n").encode())
        with open(file_path, "rb") as f:
            body.extend(f.read())
        body.extend(("\r\n--" + boundary + "--\r\n").encode())
        return bytes(body), "multipart/form-data; boundary=" + boundary

    def _request(self, path, method="GET", fields=None, file_field=None, file_path=None):
        url = API_BASE.rstrip("/") + path
        headers = {}
        data = None
        if file_path:
            data, content_type = self._multipart(fields or {}, file_field, file_path)
            headers["Content-Type"] = content_type
        elif fields is not None:
            data = json.dumps(fields).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=180) as response:
            raw = response.read()
            return json.loads(raw.decode("utf-8")) if raw else {}

    def _upload_and_poll(self):
        try:
            sample = self._request("/v1/voice-samples", "POST",
                                   {"profile_name": "Monu"}, "audio", str(VOICE_SAMPLE))
            profile_id = sample["profile_id"]
            job = self._request("/v1/convert", "POST",
                                {"profile_id": profile_id}, "video", self.video_path)
            job_id = job["job_id"]
            for _ in range(180):
                info = self._request("/v1/jobs/" + urllib.parse.quote(job_id))
                status = info.get("status")
                progress = float(info.get("progress", 10))
                Clock.schedule_once(lambda dt, p=progress: setattr(self, "progress", p))
                if status == "completed":
                    download_url = info.get("download_url")
                    if not download_url:
                        raise RuntimeError("Server ने download_url नहीं दिया।")
                    output = str(APP_DIR / "converted_video.mp4")
                    req = urllib.request.Request(download_url)
                    with urllib.request.urlopen(req, timeout=300) as response, open(output, "wb") as out:
                        out.write(response.read())
                    Clock.schedule_once(lambda dt: self._conversion_done(output))
                    return
                if status == "failed":
                    raise RuntimeError(info.get("error", "Voice conversion failed"))
                import time
                time.sleep(5)
            raise TimeoutError("Processing में बहुत समय लग रहा है।")
        except Exception as exc:
            Clock.schedule_once(lambda dt, e=str(exc): self._set_error(e))

    def _conversion_done(self, output):
        self.progress = 100
        self.status_text = "तैयार! फाइल सेव हुई: " + output

    def _set_error(self, error):
        self.status_text = "समस्या: " + error


class MonuVoiceEditorApp(App):
    def build(self):
        Builder.load_string(KV)
        return RootUI()

    def on_start(self):
        self.root._request_android_permissions()


if __name__ == "__main__":
    MonuVoiceEditorApp().run()
